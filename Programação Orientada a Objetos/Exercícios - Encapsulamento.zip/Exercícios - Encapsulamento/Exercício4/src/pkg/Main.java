package pkg;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Carro carro = new Carro();

        System.out.print("Informe a marca do carro: ");
        carro.setMarca(scanner.nextLine());

        System.out.print("Informe o modelo do carro: ");
        carro.setModelo(scanner.nextLine());

        System.out.print("Informe o ano do carro: ");
        carro.setAno(scanner.nextInt());

        carro.exibeDetalhes();
    }
}