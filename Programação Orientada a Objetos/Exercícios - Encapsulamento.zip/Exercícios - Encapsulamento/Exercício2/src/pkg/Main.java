package pkg;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Circulo circulo = new Circulo();

        System.out.print("Informe o raio do círculo: ");
        circulo.setRaio(scanner.nextDouble());

        System.out.println("Área do círculo: " + circulo.calculaArea());
    }
}