package pkg;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Retangulo retangulo = new Retangulo();

        System.out.print("Informe a base do retângulo: ");
        retangulo.setBase(scanner.nextDouble());

        System.out.print("Informe a altura do retângulo: ");
        retangulo.setAltura(scanner.nextDouble());

        System.out.println("Área do retângulo: " + retangulo.calculaArea());
    }
}