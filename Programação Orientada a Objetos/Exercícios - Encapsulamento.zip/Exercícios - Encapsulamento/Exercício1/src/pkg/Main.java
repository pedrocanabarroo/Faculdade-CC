package pkg;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ContaBancaria conta = new ContaBancaria();

        System.out.print("Informe o saldo inicial: ");
        conta.setSaldo(scanner.nextDouble());

        System.out.print("Informe o limite da conta: ");
        conta.setLimite(scanner.nextDouble());

        System.out.print("Informe o valor do saque: ");
        double valorSaque = scanner.nextDouble();

        conta.saque(valorSaque);
    }
}