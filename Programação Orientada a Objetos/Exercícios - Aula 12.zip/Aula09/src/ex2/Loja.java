package ex2;

public class Loja {

	public Produto criarProdutoDesc(String nome, double preco) {
		double precoComDesconto = preco * 0.9;
		return new Produto(nome, precoComDesconto);
	}
}
