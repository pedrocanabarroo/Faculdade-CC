package ex2;

public class Main {

	public static void main(String[] args) {
		Loja l = new Loja();
		
		Produto p = l.criarProdutoDesc("iPhone", 5000.00);
		p.exibirInfo();

		Produto p2 = l.criarProdutoDesc("Macbook", 8000.00);
		p2.exibirInfo();
	}

}
