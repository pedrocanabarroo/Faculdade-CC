package ex4;

public class Main {

	public static void main(String[] args) {
		Conta conta = new Conta("Marina", 1000.00);
		
		Banco banco = new Banco();
		
		banco.depositar(conta, 750.00);
		conta.exibeSaldo();

	}

}
