package ex4;

public class Conta {
	protected String titular;
	protected double saldo;
	
	public Conta(String titular, double saldo) {
		this.titular = titular;
		this.saldo = saldo;
	}
	
	public void exibeSaldo() {
		System.out.println("Titular: " +titular+ ", Saldo em R$: " +saldo);
	}
}
