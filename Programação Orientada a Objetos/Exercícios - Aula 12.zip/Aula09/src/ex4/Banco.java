package ex4;

public class Banco {
	public void depositar(Conta c, double valor) {
		if (valor > 0) {
			c.saldo += valor;
		}
		else {
			System.out.println("Não há como depositar valor negativo!!!!!");
		}
	}
}
