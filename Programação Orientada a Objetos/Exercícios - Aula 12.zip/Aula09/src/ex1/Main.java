package ex1;

public class Main {

	public static void main(String[] args) {
		Aluno aluno1 = new Aluno("Pedro", 5.7);
		Aluno aluno2 = new Aluno("Marina Gulosa", 7.4);

		Boletim boletim = new Boletim();
		
		boletim.imprimirStatus(aluno1);
		boletim.imprimirStatus(aluno2);
	}

}
