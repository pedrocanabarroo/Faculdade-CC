package ex1;

public class Aluno {
	String nome;
	double notaFinal;
	
	public Aluno(String nome, double notaFinal) {
		this.nome = nome;
		this.notaFinal = notaFinal;
	}
}
