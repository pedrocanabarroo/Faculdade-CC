package ex1;

public class Boletim {
	public void imprimirStatus(Aluno a) {
		if (a.notaFinal >= 6) {
			System.out.println(a.nome + " foi aprovado.");
		}
		else {
			System.out.println(a.nome + " foi reprovado.");
		}
	}
}
