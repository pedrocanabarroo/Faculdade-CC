package ex3;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		
		ArrayList<Livro> livros = new ArrayList<>();
		
		livros.add(new Livro("A Bíblia", "J.C")); //sei que são vários livros e vários autores, mas 1 comandou todos esses autores.
		livros.add(new Livro("Hamlet", "William Shakespeare"));
		livros.add(new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry"));
		
		Biblioteca biblioteca = new Biblioteca();
		biblioteca.imprimirLivros(livros);
	}

}
