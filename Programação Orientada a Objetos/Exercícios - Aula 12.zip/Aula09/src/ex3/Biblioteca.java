package ex3;

import java.util.ArrayList;

public class Biblioteca {

	public void imprimirLivros(ArrayList <Livro> lista) {
		for (Livro livro : lista) {
			System.out.println("Título: " +livro.titulo+ ", Autor: " +livro.autor);
		}
	}
}
