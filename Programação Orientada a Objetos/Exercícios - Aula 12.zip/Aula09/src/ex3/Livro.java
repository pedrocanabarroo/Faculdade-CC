package ex3;

public class Livro {
	String titulo;
	String autor;
	
	public Livro(String titulo, String autor) {
		this.titulo = titulo;
		this.autor = autor;
	}
}
