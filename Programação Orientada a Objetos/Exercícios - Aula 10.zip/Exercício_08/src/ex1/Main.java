package ex1;

public class Main {

	public static void main(String[] args) {
		FormaGeometrica forma = new Triangulo(10,5);
		forma.calcularArea();
	}

}
