package ex1;

public class FormaGeometrica {
	public void calcularArea() {
		System.out.println("Cálculo genérico da área.");
	}
}
