package ex4;

public class Casa {
	private final int precoPorMetro = 1500;
	private final int precoPorQuarto = 10000;
	
	public int calcularPreco(int tamanho) {
		return tamanho * precoPorMetro;
	}
	
	public int calcularPreco(int tamanho, int numeroDeQuartos) {
		return (tamanho * precoPorMetro) + (numeroDeQuartos * precoPorQuarto);
	}
}
