package ex4;

public class Imobiliaria {

	public static void main(String[] args) {
		Casa casa = new Casa();
		System.out.println("O preço da casa (somente o tamanho): R$" + casa.calcularPreco(100));
		System.out.println("O preço da casa (tamanho + quartos): R$" +casa.calcularPreco(100, 3));

	}

}
