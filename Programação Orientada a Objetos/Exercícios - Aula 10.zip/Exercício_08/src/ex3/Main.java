package ex3;

public class Main {

	public static void main(String[] args) {
		Pessoa p = new Pessoa();
		p.falar("Olá");
		p.falar("Bom dia professor Ricardo!", 20);

	}

}
