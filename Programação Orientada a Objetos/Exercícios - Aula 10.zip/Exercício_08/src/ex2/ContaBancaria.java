package ex2;

public class ContaBancaria {
	protected double saldo;
	
	public ContaBancaria(double saldo) {
		this.saldo = saldo;
	}
	
	public void calcularSaldo() {
		System.out.println("O saldo da conta bancária é: "+saldo);
	}
}
