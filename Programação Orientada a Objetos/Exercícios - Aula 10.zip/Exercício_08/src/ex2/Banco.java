package ex2;

public class Banco {

	public static void main(String[] args) {
		ContaBancaria conta = new ContaCorrente(1000,15);
		conta.calcularSaldo();

	}

}
