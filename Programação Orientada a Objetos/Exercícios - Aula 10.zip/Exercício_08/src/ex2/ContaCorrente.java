package ex2;

public class ContaCorrente extends ContaBancaria{
	private double taxaMensal;
	
	public ContaCorrente(double saldo, double taxaMensal) {
		super(saldo);
		this.taxaMensal = taxaMensal;
	}
	
	@Override
	public void calcularSaldo() {
		double saldoFinal = saldo - taxaMensal;
		System.out.println("Saldo da conta corrente com a taxa: "+saldoFinal);
	}
}
