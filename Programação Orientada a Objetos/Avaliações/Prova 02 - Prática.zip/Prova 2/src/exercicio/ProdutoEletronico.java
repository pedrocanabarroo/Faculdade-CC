package exercicio;

public class ProdutoEletronico extends Produto {
	public int garantia;
	
	public ProdutoEletronico (String nome, double preco, double percentualDesconto, int garantia) {
		super(nome, preco, percentualDesconto);
		this.garantia = garantia;
	}
	
	@Override
	public double aplicarDesconto() {
		if (percentualDesconto == 0) {
			return preco;
		}
		else {
			return preco * percentualDesconto;
		}
	}
	
	@Override
	public double calcularPrecoFinal() {
		if (garantia == 0) {
			return preco * percentualDesconto;
		}
		if (garantia == 1) { // garantia de 1 ano
			return (preco * percentualDesconto) + (preco * 0.25) ;
		}
		if (garantia == 2) { // garantia de 2 anos
			return (preco * percentualDesconto) + (preco * 0.5) ;
		}
		return garantia;

	}
		
}
