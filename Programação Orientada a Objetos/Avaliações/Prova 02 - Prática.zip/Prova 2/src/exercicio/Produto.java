package exercicio;

public class Produto {
	
	protected String nome;
	protected double preco;
	protected double percentualDesconto;
	
	public Produto (String nome, double preco, double percentualDesconto) {
		this.nome = nome;
		this.preco = preco;
		this.percentualDesconto = percentualDesconto;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public double getPercentualDesconto() {
		return percentualDesconto;
	}

	public void setPercentualDesconto(double percentualDesconto) {
		this.percentualDesconto = percentualDesconto;
	}

	public double aplicarDesconto() {
		return percentualDesconto;
	}
	
	public double calcularPrecoFinal() {
		return preco * percentualDesconto;
	}

}
