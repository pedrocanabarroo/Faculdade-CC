package exercicio;

public class ProdutoAlimenticio extends Produto{
	public int validade;
	
	public ProdutoAlimenticio (String nome, double preco, double percentualDesconto, int validade) {
		super(nome, preco, percentualDesconto);
		this.validade = validade;
	}
	
	@Override
	public double calcularPrecoFinal() {
		if (validade < 2) { //nesse caso o desconto será considerado até 2 meses de validade do produto.
			return (preco * percentualDesconto) - (preco * 0.18);
		}
		else {
			return preco * percentualDesconto;
		}
	}
	
	


}
