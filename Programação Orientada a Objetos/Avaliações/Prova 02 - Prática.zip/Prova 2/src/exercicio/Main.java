package exercicio;

public class Main {

	public static void main(String[] args) {

		//esqueci como que faz a lista :D
		
		

	}

}
