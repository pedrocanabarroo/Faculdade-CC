//Pedro Henrique Canabarro - Prova 01 - 22/04/2025
package pkg;

public class Produto {
	private String nome;
	private double preco;
	private int quantidadeEstoque;
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPreco() {
		return preco;
	}

	public void setPreco(double preco) {
		this.preco = preco;
	}

	public int getQuantidadeEstoque() {
		return quantidadeEstoque = 0;
	}

	public void setQuantidadeEstoque(int quantidadeEstoque) {
		this.quantidadeEstoque = quantidadeEstoque;
	}
	public void exibirInformacoes(){
		System.out.println("O nome do produto: "+nome);
		System.out.println("O preço do produto: "+preco);
		System.out.println("A quantidade no estoque do produto: "+quantidadeEstoque);
		
	}
}
