//Pedro Henrique Canabarro - Prova 01 - 22/04/2025
package pkg;

import java.util.Scanner;

public class mainProduto {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		Produto p = new Produto();
		
		System.out.println("1 - Criar produto informando nome");
		System.out.println("2 - Criar produto informando nome e preço");
		System.out.println("3 - Exibir informações do produto");
		System.out.println("4 - Atribuir nome do produto");
		System.out.println("5 - Obter nome do produto");
		System.out.println("6 - Atribuir preço do produto");
		System.out.println("7 - Obter preço do produto");
		System.out.println("8 - Atribuir quantidade em estoque");
		System.out.println("9 - Obter quantidade em estoque");
		System.out.println("0 - Sair");
		
		System.out.println("Qual opção deseja escolher? ");
		int opcao = sc.nextInt();
		
		if (opcao == 1) {
			System.out.println("Qual produto deseja criar? ");
			p.setNome(sc.next());
			System.out.println("Produto "+p.getNome()+"Criado");
		}
		if (opcao == 2) {
			System.out.println("Qual produto deseja criar? ");
			p.setNome(sc.next());
			System.out.println("\nE qual o valor desse produto? ");
			p.setPreco(sc.nextDouble());
			System.out.println("O produto "+p.getNome()+" foi criado e seu valor é de: "+p.getPreco()+" reais.");			
		}
		if (opcao == 3) {
			System.out.println("Informe o nome do produto: ");
	        p.setNome(sc.next());

	        System.out.println("\nInforme o preço do produto: ");
	        p.setPreco(sc.nextDouble());

	        System.out.println("Informe a quantidade do produto: ");
	        p.setQuantidadeEstoque(sc.nextInt());
	        
	        p.exibirInformacoes();
		}
		if (opcao == 4) {
			System.out.println("Atribuindo nome ao produto: ");
			p.setNome(sc.next());
			System.out.println("Produto "+p.getNome()+" criado.");
		}
		if (opcao == 5) {
			System.out.println("Obtendo o nome do produto: ");
			p.getNome();
		}
		if (opcao == 6) {
			System.out.println("Atribuindo preço ao produto: ");
			p.setPreco(sc.nextDouble());
			System.out.println("Valor R$"+p.getPreco()+" atribuido.");
		}
		if (opcao == 7) {
			System.out.println("Obtendo o preço do produto: ");
			p.getPreco();
			System.out.println("Valor R$"+p.getPreco()+" atribuido.");
		}
		if (opcao == 8) {
			System.out.println("Atribuindo quantidade em estoque: ");
			p.setQuantidadeEstoque(sc.nextInt());
			System.out.println("Quantidade no estoque: "+p.getQuantidadeEstoque());
		}
		if (opcao == 9) {
			System.out.println("Obtendo a quantidade em estoque do produto: ");
			p.getQuantidadeEstoque();
			System.out.println("Quantidade no estoque: "+p.getQuantidadeEstoque());
		}
		if (opcao == 0) {
			System.out.println("Saindo do sistema...");
		}
		
		//else {
		//	System.out.println("Opção inválida!!!");
		//}
		//Sei que se digitar uma opção diferente da do menu, pode dar erro no programa, tentei colocar esse ELSE mas
		//da erro também...
		sc.close();
		
	}

}
