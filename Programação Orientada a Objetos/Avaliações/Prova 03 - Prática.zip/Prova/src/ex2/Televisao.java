package ex2;

public class Televisao implements Controlavel{
	
	public void ligar() {
		System.out.println("Televisão ligando...");
		System.out.println("Televisão ligada!!!");
	}
	
	public void desligar() {
		System.out.println("Televisão desligando...");
		System.out.println("Televisão desligada!!!");
	}
}
