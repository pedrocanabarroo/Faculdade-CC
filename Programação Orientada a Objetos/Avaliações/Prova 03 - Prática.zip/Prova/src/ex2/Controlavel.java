package ex2;

public interface Controlavel {
	void ligar();
	void desligar();
}
