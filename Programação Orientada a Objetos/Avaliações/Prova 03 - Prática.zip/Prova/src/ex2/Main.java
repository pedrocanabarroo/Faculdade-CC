package ex2;

public class Main {

	public static void main(String[] args) {
		
		Lampada lampada = new Lampada();
		lampada.ligar();
		lampada.desligar();
		
		Televisao televisao = new Televisao();
		televisao.ligar();
		televisao.desligar();
		
		
		
		

	}

}
