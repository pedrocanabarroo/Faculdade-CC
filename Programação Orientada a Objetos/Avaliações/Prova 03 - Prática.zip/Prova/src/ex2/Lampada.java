package ex2;

public class Lampada {
	
	public void ligar() {
		System.out.println("Lampada ligando...");
		System.out.println("Lampada ligada!!!");
	}
	
	public void desligar() {
		System.out.println("Lampada desligando...");
		System.out.println("Lampada desligada!!!");
		
		System.out.println("\n");
	}

}
