//Crie uma classe Funcionario com um método calcularSalario(). Em seguida, crie uma classe
//Gerente que herda da classe Funcionario e sobrescreve o método calcularSalario() para calcular
//o salário do gerente com base em um bônus e imprimir o resultado.

package pkg;

public class Funcionario {
	
	protected String nome;
	protected double salario;
	
	public Funcionario(String nome, double salario) {
		this.nome = nome;
		this.salario = salario;
	}
	
	public void calcularSalario() {
		System.out.println("O nome deste funcionário é: "+nome);
		System.out.println("O salário deste funcionario é de: R$ "+salario);
	}

}
