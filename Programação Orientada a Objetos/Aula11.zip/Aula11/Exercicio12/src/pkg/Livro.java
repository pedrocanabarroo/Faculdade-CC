//Crie uma classe Livro com atributos titulo, autor e ano. Crie uma lista de
//livros e adicione alguns livros nessa lista. Em seguida, ordene a lista de livros
//pelo ano de lançamento e imprima os dados de cada livro.
package pkg;

public class Livro {

	private String titulo;
	private String autor;
	private int ano;
	
	public Livro(String titulo, String autor, int ano) {
		this.titulo = titulo;
		this.autor = autor;
		this.ano = ano;
	}

	public String getTitulo() {
		return titulo;
	}

	public String getAutor() {
		return autor;
	}

	public int getAno() {
		return ano;
	}
	
	@Override
    public String toString() {
        return "Nome da obra: " + titulo + ", Nome do autor: " + autor + ", Ano de publicação: " + ano;
    }
}
