package pkg;

public class Main {

	public static void main(String[] args) {
		Produto p1 = new Produto("Mesa", 450.00);
		p1.desconto();
		
		System.out.println();
		
		ProdutoComDesconto p2 = new ProdutoComDesconto("Tablet", 650.00, 20);
		p2.desconto();

	}
}
