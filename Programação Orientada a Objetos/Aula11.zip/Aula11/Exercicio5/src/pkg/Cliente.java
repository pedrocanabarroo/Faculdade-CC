package pkg;

public class Cliente {

	private String nome;
	private double percentualDesconto;
	
	public Cliente (String nome, double percentualDesconto) {
		this.nome = nome;
		this.percentualDesconto = percentualDesconto;
	}

	public String getNome() {
		return nome;
	}

	public double getPercentualDesconto() {
		return percentualDesconto;
	}

}
