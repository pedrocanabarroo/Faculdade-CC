package pkg;

public class Main {

	public static void main(String[] args) {
		Produto p = new Produto("Notebook");
		Cliente c = new Cliente("Leonardo", 15.0);
		
		System.out.println("------sem desconto pro cliente------");
		p.calcularPrecoFinal(4000.00);
		
		System.out.println("\n------com desconto pro cliente------");
		p.calcularPrecoFinal(4000.00, c);

	}

}
