package pkg;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Produto> produtos = new ArrayList<>();
		
		produtos.add(new Produto("Arroz", 5.99, 100));
        produtos.add(new Produto("Feijão", 7.49, 50));
        produtos.add(new Produto("Macarrão", 3.99, 200));
        produtos.add(new Produto("Açúcar", 4.29, 150));
		

        for (Produto produto : produtos) {
            System.out.println(produto);
        }
	}

}
