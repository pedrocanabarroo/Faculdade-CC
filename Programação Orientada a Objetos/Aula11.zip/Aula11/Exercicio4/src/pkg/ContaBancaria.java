//Crie uma classe ContaBancaria com um método depositar(double valor) que adiciona o valor
//passado como parâmetro ao saldo da conta. Sobrecarregue o método depositar() para aceitar um
//objeto Cheque e adicionar o valor do cheque ao saldo da conta.

package pkg;

public class ContaBancaria {

	private double saldo;

	public ContaBancaria() {
		this.saldo = 0.0;
	}
	
	public void depositar(double valor) {
		saldo += valor;
		System.out.println("Depósito em dinheiro: R$ " + valor);
        System.out.println("Saldo atual: R$ " + saldo);
	}
	
	public void depositar(Cheque cheque) {
		saldo += cheque.getValor();
		System.out.println("O depósito por chegue do banco " +cheque.getBanco() + ": R$ " +cheque.getValor());
		System.out.println("Saldo atual: R$ "+saldo);
	}
	
	public double getSaldo() {
		return saldo;
	}    
}
