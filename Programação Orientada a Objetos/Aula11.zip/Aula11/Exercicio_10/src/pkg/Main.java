package pkg;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Aluno> alunos = new ArrayList<>();
		
		alunos.add(new Aluno("Pedro", 5.90, 9.50));
		alunos.add(new Aluno("Marcos", 6.55, 8.25));
		alunos.add(new Aluno("Gabriela", 4.85, 6.15));
		alunos.add(new Aluno("João", 7.5, 8.0));
        alunos.add(new Aluno("Maria", 5.0, 6.0));
        alunos.add(new Aluno("Carlos", 4.5, 3.5));
        alunos.add(new Aluno("Ana", 9.0, 8.5));
        
        for (Aluno aluno : alunos) {
            double media = aluno.calcularMedia();
            if (media >= 6.0) {
                System.out.println(aluno + " - Aprovado");
            } else {
                System.out.println(aluno + " - Reprovado");
            }
        }
		
	}

}
