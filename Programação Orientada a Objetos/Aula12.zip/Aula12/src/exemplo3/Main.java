package exemplo3;

public class Main {

	public static void main(String[] args) {
		Pessoa2 pessoa = new Pessoa2("João", 30, new Endereco("Rua 1", 123));
		
		System.out.println("Nome: "+pessoa.getNome());
		System.out.println("Idade: "+pessoa.getIdade());
		System.out.println("Endereço: "+pessoa.getEndereco().getRua()+ ", " + "" +pessoa.getEndereco().getNumero());

	}

}
