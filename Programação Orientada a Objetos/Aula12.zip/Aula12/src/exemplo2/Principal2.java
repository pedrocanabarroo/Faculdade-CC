package exemplo2;

public class Principal2 {

	public static void main(String[] args) {
		Produto p1 = new Produto("Caneta",1.5);
		Produto p2 = p1.clone();
		
		System.out.println("Produto 1 - Nome: " +p1.getNome() + ", Preço: " +p1.getPreco());
		System.out.println("Produto 2 - Nome: " +p2.getNome() + ", Preço: " +p2.getPreco());
		
		p2.setPreco(2.0);
		System.out.println("Produto 1 - Nome: " +p1.getNome() + ", Preço: " +p1.getPreco());
		System.out.println("Produto 2 - Nome: " +p2.getNome() + ", Preço: " +p2.getPreco());
		
		if(p1 == p2) {
			System.out.println("São Iguais.");
		}
		else {
			System.out.println("Sâo diferentes.");
		}

	}

}
