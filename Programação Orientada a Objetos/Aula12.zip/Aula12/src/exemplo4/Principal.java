package exemplo4;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	public static void main(String[] args) {
		List<Pessoa> listaPessoas = new ArrayList<Pessoa>();
		
		Pessoa p1 = new Pessoa("João", 30);
		Pessoa p2 = new Pessoa("Maria", 25);
		Pessoa p3 = new Pessoa("Pedro", 40);
		
		listaPessoas.add(p1);
		listaPessoas.add(p2);
		listaPessoas.add(p3);
		
		exibirPessoas(listaPessoas);
	}
	
	public static void exibirPessoas(List<Pessoa> lista) {
		for(Pessoa p : lista) {
			System.out.println("Nome: " +p.getNome());
			System.out.println("Idade: " +p.getIdade());
		}
	}
	
	private static void exibirPessoas2(List<Pessoa> lista) {
		for(int i=0; i<lista.size(); i++) {
			System.out.println("Nome: " +lista.get(i).getNome());
			System.out.println("Idade: " +lista.get(i).getIdade());
		}
	}

}
