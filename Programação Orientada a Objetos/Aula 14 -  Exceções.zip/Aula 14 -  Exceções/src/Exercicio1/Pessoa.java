//Use uma classe Pessoa crie um construtor que inicialize esses atributos e um método validarIdade que lance uma 
//exceção caso a idade informada seja menor que zero ou maior que 120.
package Exercicio1;

public class Pessoa {
	private String nome;
	private int idade;
	
	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}

	public Pessoa(String nome, int idade) throws IdadeInvalida{
		this.nome = nome;
		this.idade = idade;
		validarIdade();
	}
	
	public void validarIdade() throws IdadeInvalida {
		if(idade < 0 || idade > 120) {
			throw new IdadeInvalida("Idade inválida: " +idade+ ". A idade deve estar entre 0 e 120");
		}
	}
}
