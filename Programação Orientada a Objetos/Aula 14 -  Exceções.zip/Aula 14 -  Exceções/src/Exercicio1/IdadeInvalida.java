package Exercicio1;

public class IdadeInvalida extends Exception{
	public IdadeInvalida(String mensagem) {
		super(mensagem);
	}

}
