package Exercicio1;

public class Main {

	public static void main(String[] args) {

		try {
			Pessoa p1 = new Pessoa("Maria", 30);
			System.out.println("Pessoa criada: "+p1.getNome() + ", " +p1.getIdade() + " anos.");
			
			Pessoa p2 = new Pessoa("João", -5);
		}
		catch (IdadeInvalida e){
			System.out.println("Erro ao criar pessoa: " +e.getMessage());
		}
	}
}
