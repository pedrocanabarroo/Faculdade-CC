package Exercicio2;

public class Main {

	public static void main(String[] args) {
		try {
			Triangulo t1 = new Triangulo(3, 4, 5);
			System.out.println("Triangulo criado: lados " +t1.getLado1()+ ", " +t1.getLado2()+ ", " +t1.getLado3());
			
			Triangulo t2 = new Triangulo(1, 2, 3);
			
			Triangulo t3 = new Triangulo(-2, 0, 5);
		}
		catch(IllegalArgumentException e) {
			System.out.println("Erro ao criar o triângulo. " +e.getMessage());
		}
	}
}
