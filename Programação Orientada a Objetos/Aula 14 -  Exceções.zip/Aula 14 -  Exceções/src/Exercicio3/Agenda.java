//Crie uma classe Agenda com um método adicionarContato que receba o nome e o telefone de um contato e lance uma exceção 
//IllegalArgumentException caso o nome ou o telefone sejam nulos ou vazios.
package Exercicio3;

public class Agenda {

	private String nome;
	private String telefone;
	
	public Agenda(String nome, String telefone) {
		this.nome = nome;
		this.telefone = telefone;
		adicionarContato();
	}
	
	public void adicionarContato() {
		if (nome == null || nome == " " || telefone == null || telefone == " ") {
			throw new IllegalArgumentException("Erro ao adicionar o contato. ");
		}

	}

	public String getNome() {
		return nome;
	}

	public String getTelefone() {
		return telefone;
	}
}
