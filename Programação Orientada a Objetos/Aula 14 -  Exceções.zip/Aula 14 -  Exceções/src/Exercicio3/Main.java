package Exercicio3;

import Exercicio2.Triangulo;

public class Main {

	public static void main(String[] args) {
		try {
			Agenda a1 = new Agenda("João", "99999 - 9999");
			System.out.println("Nome do contato " +a1.getNome()+ ", " +a1.getTelefone());
			
			Agenda a2 = new Agenda(" ", " ");
			System.out.println("Nome do contato " +a2.getNome()+ ", " +a2.getTelefone());
		}
		catch(IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}

}
