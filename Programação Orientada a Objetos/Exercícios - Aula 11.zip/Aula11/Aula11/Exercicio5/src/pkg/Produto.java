//Crie uma classe Produto com um método calcularPrecoFinal(double preco) que retorna o
//preço final do produto com base no preço passado como parâmetro. Sobrecarregue o método
//calcularPrecoFinal() para aceitar um objeto Cliente e calcular o preço final do produto com base
//no desconto do cliente.
package pkg;

public class Produto {
	
	private String nome;
	
	public Produto(String nome) {
		this.nome = nome;
	}
	
	public double calcularPrecoFinal(double preco) {
		System.out.println("Produto: "+nome);
		System.out.println("Preço do produto: R$"+preco);
		return preco;
	}
	
	public double calcularPrecoFinal(double preco, Cliente cliente) {
		double desconto = preco * (cliente.getPercentualDesconto()/100);
		double precoFinal = preco - desconto;
		System.out.println("Produto: "+nome);
		System.out.println("Cliente: "+cliente.getNome());
		System.out.println("Desconto foi de: " +cliente.getPercentualDesconto()+ " %" );
		System.out.println("Preço com desconto: "+precoFinal);
		return precoFinal;
		
	}

}
