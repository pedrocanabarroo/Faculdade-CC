//Crie uma classe Funcionario com um método calcularSalario(). Em seguida, crie uma classe
//Gerente que herda da classe Funcionario e sobrescreve o método calcularSalario() para calcular
//o salário do gerente com base em um bônus e imprimir o resultado.

package pkg;

public class Gerente extends Funcionario{
	
	private double bonus;
	
	public Gerente(String nome, double salario, double bonus) {
		super(nome,salario);
		this.bonus = bonus;
	}
	
	@Override
	public void calcularSalario() {
		double novoSalario = salario + bonus;
		System.out.println("Gerente: " + nome);
        System.out.println("Salário base: R$ " + salario);
        System.out.println("Bônus: R$ " + bonus);
        System.out.println("Salário total: R$ " + novoSalario);
    }
}
