package pkg;

public class Main {

	public static void main(String[] args) {
		Funcionario fun1 = new Funcionario("Ricardo",3000.00);
		fun1.calcularSalario();
		
		System.out.println();
		
		Gerente gen1 = new Gerente("Pedro", 5000.00, 1200.00);
		gen1.calcularSalario();

	}

}
