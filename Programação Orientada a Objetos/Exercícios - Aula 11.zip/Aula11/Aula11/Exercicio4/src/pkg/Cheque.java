package pkg;

public class Cheque {

	private double valor;
	private String banco;
	
	public Cheque(String banco, double valor) {
		this.banco = banco;
		this.valor = valor;
	}

	public double getValor() {
		return valor;
	}

	public String getBanco() {
		return banco;
	}
}
