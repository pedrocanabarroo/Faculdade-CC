package pkg;

public class Main {

	public static void main(String[] args) {
		ContaBancaria conta = new ContaBancaria();
		
		conta.depositar(800);
		
		System.out.println();
		
		Cheque cheque = new Cheque("Itaú", 1700.00);
		conta.depositar(cheque);
		
		

	}

}
