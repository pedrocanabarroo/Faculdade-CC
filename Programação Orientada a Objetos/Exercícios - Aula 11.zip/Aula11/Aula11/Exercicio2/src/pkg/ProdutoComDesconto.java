package pkg;

public class ProdutoComDesconto extends Produto {
 
	private double percentualDesconto;
	
	public ProdutoComDesconto(String nome, double preco, double percentualDesconto) {
		super(nome,preco);
		this.percentualDesconto = percentualDesconto;
	}
	
	@Override
	public void desconto() {
		double novoValor = preco - (preco*percentualDesconto/100);
		System.out.println("Produto: "+nome);
		System.out.println("Preço original: R$ "+preco);
		System.out.println("Desconto de: " +percentualDesconto+ "%");
		System.out.println("Preço com o desconto: R$ "+novoValor);
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	

 
