//Crie uma classe Pessoa com atributos nome, idade e sexo. Crie uma lista de
//pessoas e adicione algumas pessoas nessa lista. Em seguida, crie um método que
//recebe uma lista de pessoas e retorna a quantidade de mulheres. Por fim, chame
//esse método passando a lista de pessoas e imprima a quantidade de mulheres.
package pkg;

public class Pessoa {
	
	private String nome;
	private int idade;
	private String sexo;
	
	public Pessoa(String nome, int idade, String sexo) {
		this.nome = nome;
		this.idade = idade;
		this.sexo = sexo;
	}

	public String getNome() {
		return nome;
	}

	public int getIdade() {
		return idade;
	}

	public String getSexo() {
		return sexo;
	}

	@Override
    public String toString() {
        return "Nome: " + nome + ", Idade: " + idade + ", Sexo: " + sexo;
    }
}
