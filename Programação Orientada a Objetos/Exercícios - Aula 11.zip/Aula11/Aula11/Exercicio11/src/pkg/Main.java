package pkg;

import java.util.ArrayList;
import java.util.List;

public class Main {

	public static int contarMulheres(List<Pessoa> pessoas) {
		int quantidadeMulheres = 0;
		for (Pessoa pessoa : pessoas) {
			if(pessoa.getSexo().equalsIgnoreCase("Feminino")) {
				quantidadeMulheres++;
			}
		}
		return quantidadeMulheres;
	}
	
	public static void main(String[] args) {
		List<Pessoa> pessoas = new ArrayList<>();
		
		pessoas.add(new Pessoa("João", 30, "Masculino"));
	    pessoas.add(new Pessoa("Maria", 25, "Feminino"));
	    pessoas.add(new Pessoa("Carlos", 40, "Masculino"));
	    pessoas.add(new Pessoa("Ana", 22, "Feminino"));
	    pessoas.add(new Pessoa("Juliana", 35, "Feminino"));
	    
	    int quantidadeMulheres = contarMulheres(pessoas);
	    System.out.println("Quantidade de mulheres: "+quantidadeMulheres);
	}

}
