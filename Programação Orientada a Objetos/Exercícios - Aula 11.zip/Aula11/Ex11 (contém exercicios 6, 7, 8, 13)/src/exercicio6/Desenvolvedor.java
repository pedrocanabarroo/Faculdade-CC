package exercicio6;

class Desenvolvedor extends Funcionario {
    private int horasExtras;
    private double valorHoraExtra;

    public Desenvolvedor(String nome, double salario, int horasExtras, double valorHoraExtra) {
        super(nome, salario);
        this.horasExtras = horasExtras;
        this.valorHoraExtra = valorHoraExtra;
    }

    // Sobrecarga considerando horas extras
    public void aumentarSalario(double percentual, boolean incluirHorasExtras) {
        this.salario += this.salario * percentual / 100;
        if (incluirHorasExtras) {
            this.salario += horasExtras * valorHoraExtra;
        }
    }

    @Override
    public String toString() {
        return "Desenvolvedor: " + nome + ", Salário: R$" + salario +
                ", Horas Extras: " + horasExtras + ", Valor Hora Extra: R$" + valorHoraExtra;
    }
}