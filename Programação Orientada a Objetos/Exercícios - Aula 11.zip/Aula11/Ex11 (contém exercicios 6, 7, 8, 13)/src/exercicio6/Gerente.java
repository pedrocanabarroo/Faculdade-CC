package exercicio6;

class Gerente extends Funcionario {
	private double bonusAnual;
	
	public Gerente(String nome, double salario, double bonusAnual) {
		super(nome, salario);
		this.bonusAnual = bonusAnual;
	}
	
	public void aumentarSalario(double percentual, boolean considerarBonus) {
		this.salario += this.salario * percentual / 100;
		if(considerarBonus) {
			this.salario += bonusAnual;
		}
	}
	
	@Override
	public String toString() {
		return "Gerente: " +nome+ ", Salário: R$" +salario+ ", Bônus Anual: R$" +bonusAnual;
	}
}
