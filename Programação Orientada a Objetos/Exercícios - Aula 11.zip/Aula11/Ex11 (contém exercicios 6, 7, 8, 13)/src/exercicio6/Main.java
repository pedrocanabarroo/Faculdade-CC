package exercicio6;

public class Main {
    public static void main(String[] args) {
        Funcionario[] funcionarios = new Funcionario[3];

        funcionarios[0] = new Gerente("Ana", 8000.00, 3000.00);
        funcionarios[1] = new Desenvolvedor("Bruno", 5000.00, 10, 50.00);
        funcionarios[2] = new Funcionario("Carlos", 4000.00);

        // Aplicar aumentos
        ((Gerente) funcionarios[0]).aumentarSalario(10, true);
        ((Desenvolvedor) funcionarios[1]).aumentarSalario(8, true);
        funcionarios[2].aumentarSalario(5);

        // Exibir informações
        for (Funcionario f : funcionarios) {
            System.out.println(f);
        }
    }
}