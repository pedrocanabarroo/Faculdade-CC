package exercicio6;

public class Funcionario {
	protected String nome;
	protected double salario;
	
	public Funcionario(String nome, double salario) {
		this.nome = nome;
		this.salario = salario;
	}
	
	public void aumentarSalario(double percentual) {
		this.salario += this.salario * percentual / 100;
	}
	
	@Override
	public String toString() {
		return "Funcionário: " + nome + ", Salário: R$" + salario;
	}
}
