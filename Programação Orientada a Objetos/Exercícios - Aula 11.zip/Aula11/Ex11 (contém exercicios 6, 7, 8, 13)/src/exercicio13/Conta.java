package exercicio13;

public class Conta {
    private int numero;
    private String titular;
    private double saldo;

    public Conta(int numero, String titular, double saldo) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = saldo;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getTitular() {
        return titular;
    }

    public int getNumero() {
        return numero;
    }

    @Override
    public String toString() {
        return "Conta{" +
               "numero=" + numero +
               ", titular='" + titular + '\'' +
               ", saldo=" + saldo +
               '}';
    }
}