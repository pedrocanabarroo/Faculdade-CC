package exercicio13;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static Conta encontrarContaComMaiorSaldo(List<Conta> contas) {
        if (contas == null || contas.isEmpty()) {
            return null;
        }

        Conta maiorSaldo = contas.get(0);
        for (Conta conta : contas) {
            if (conta.getSaldo() > maiorSaldo.getSaldo()) {
                maiorSaldo = conta;
            }
        }
        return maiorSaldo;
    }

    public static void main(String[] args) {
        List<Conta> contas = new ArrayList<>();
        contas.add(new Conta(1, "Alice", 1500.50));
        contas.add(new Conta(2, "Bruno", 2750.00));
        contas.add(new Conta(3, "Carla", 1980.75));

        Conta contaMaiorSaldo = encontrarContaComMaiorSaldo(contas);
        if (contaMaiorSaldo != null) {
            System.out.println("Conta com maior saldo:");
            System.out.println(contaMaiorSaldo);
        } else {
            System.out.println("Lista de contas vazia.");
        }
    }
}
