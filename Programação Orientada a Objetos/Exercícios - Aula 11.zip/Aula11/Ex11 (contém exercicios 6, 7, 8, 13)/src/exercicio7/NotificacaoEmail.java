package exercicio7;

class NotificacaoEmail extends Notificacao {
    public void enviar(String mensagem, String destinatario) {
        System.out.println("Enviando e-mail para " + destinatario + ": " + mensagem);
    }

    public void enviar(String mensagem, String[] destinatarios) {
        for (String d : destinatarios) {
            enviar(mensagem, d);
        }
    }

    @Override
    public void enviar(String mensagem) {
        System.out.println("Enviando e-mail padrão: " + mensagem);
    }
}