package exercicio7;

class NotificacaoApp extends Notificacao {
    public void enviar(String mensagem) {
        System.out.println("Enviando notificação via App: " + mensagem);
    }
}