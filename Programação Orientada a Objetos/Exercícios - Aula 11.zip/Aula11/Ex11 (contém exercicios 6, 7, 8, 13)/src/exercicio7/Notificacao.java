package exercicio7;

class Notificacao {
    public void enviar(String mensagem) {
        System.out.println("Enviando notificação genérica: " + mensagem);
    }
}
