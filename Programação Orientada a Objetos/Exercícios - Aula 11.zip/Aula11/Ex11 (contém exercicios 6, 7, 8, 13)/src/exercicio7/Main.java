package exercicio7;

public class Main {
    public static void main(String[] args) {
        NotificacaoEmail email = new NotificacaoEmail();
        NotificacaoApp app = new NotificacaoApp();

        System.out.println("=== Notificações por Email ===");
        email.enviar("Olá, bem-vindo!", "joao@email.com");
        email.enviar("Atualização disponível", new String[]{"ana@email.com", "maria@email.com"});
        email.enviar("Mensagem genérica sem destinatário específico");

        System.out.println("\n=== Notificação por App ===");
        app.enviar("Você tem uma nova mensagem!");
    }
}