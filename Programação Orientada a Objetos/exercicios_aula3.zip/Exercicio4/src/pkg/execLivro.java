package pkg;

//Crie uma classe Livro com os atributos título, autor e ano de publicação. Faça leitura pelo teclado e imprima as informações do livro na tela.

import java.util.Scanner;

public class execLivro {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		Livro l = new Livro ();
		System.out.println("Digite o nome da obra: ");
		l.titulo = teclado.nextLine();
		System.out.println("Digite o nome do autor: ");
		l.autor = teclado.nextLine();
		System.out.println("Digite o ano da publicação: ");
		l.anopub = teclado.nextInt();
		System.out.println("O nome do livro é: "+l.titulo);
		System.out.println("A idade da pessoa é : "+l.autor);
		System.out.println("O gênero da pessoa é: "+l.anopub);
		
		teclado.close();

	}

}
