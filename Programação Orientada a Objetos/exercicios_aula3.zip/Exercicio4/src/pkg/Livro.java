package pkg;
//Crie uma classe Livro com os atributos título, autor e ano de publicação. Faça leitura pelo teclado e imprima as informações do livro na tela.
public class Livro {
		public String titulo;
		public String autor;
		public int anopub;
}
