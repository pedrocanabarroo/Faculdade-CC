package pkg;

//Crie uma classe chama Computador que possua 4 atributos: marca, modelo, tipo (notebook,
//netbook, tablet, etc) e preço.
//Essa classe Computador também deverá ser executável, entretanto crie uma outra classe
//executável que irá instanciar a classe Computador, criando 2 objetos. O primeiro objeto deverá
//ser criado através da solicitação dos valores ao usuário por linha de execução. Já, os valores do
//segundo objeto, deverão ser definidos no código-fonte da classe que o criou. Exiba na tela os
//resultados.

public class Computador {
	
public static void main(String[] args) {
	
}
	public String marca;
	public String modelo;
	public String tipo;
	public int preco;

}
