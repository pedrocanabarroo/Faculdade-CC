package pkg;

import java.util.Scanner;

//Crie uma classe chama Computador que possua 4 atributos: marca, modelo, tipo (notebook,
//netbook, tablet, etc) e preço.
//Essa classe Computador também deverá ser executável, entretanto crie uma outra classe
//executável que irá instanciar a classe Computador, criando 2 objetos. O primeiro objeto deverá
//ser criado através da solicitação dos valores ao usuário por linha de execução. Já, os valores do
//segundo objeto, deverão ser definidos no código-fonte da classe que o criou. Exiba na tela os
//resultados.

public class execComputador {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		Computador c = new Computador();
		System.out.println("Digite o nome da marca do dispositivo: ");
		c.marca = teclado.nextLine();
		System.out.println("Digite o modelo da marca: ");
		c.modelo = teclado.nextLine();
		System.out.println("Digite o tipo de dispositivo: ");
		c.tipo = teclado.nextLine();
		System.out.println("Digite o valor do dispositivo");
		c.preco = teclado.nextInt();
		System.out.println("O nome da marca é: "+c.marca);
		System.out.println("O modelo é: "+c.modelo);
		System.out.println("O tipo de dispositivo é: "+c.tipo);
		System.out.println("O valor do dispositivo é: "+c.preco);
		teclado.nextLine();
		
		Computador c2 = new Computador();
		c2.marca = "Lenovo";
		c2.modelo = "Lenovo C5";
		c2.tipo = "Notebook";
		c2.preco = 4500;
		System.out.println("\nO nome da marca do segundo computador é: "+c2.marca);
		System.out.println("O modelo do segundo é: "+c2.modelo);
		System.out.println("O tipo de dispositivo do segundo é: "+c2.tipo);
		System.out.println("O valor do dispositivo do segundo é: "+c2.preco);
		teclado.close();
		

	}

}
