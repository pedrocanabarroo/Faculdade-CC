package pkg;

//Crie uma classe Pessoa com os atributos nome, idade e gênero. Faça leitura pelo teclado e imprima as informações da pessoa na tela.
import java.util.Scanner;

public class execPessoa {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		Pessoa p = new Pessoa ();
		System.out.println("Digite o nome da pessoa: ");
		p.nome = teclado.nextLine();
		System.out.println("Digite a idade: ");
		p.idade = teclado.nextInt();
		System.out.println("Digite o gênero da pessoa: ");
		teclado.nextLine();
		p.genero = teclado.nextLine();
		System.out.println("O nome da pessoa é: "+p.nome);
		System.out.println("A idade da pessoa é : "+p.idade);
		System.out.println("O gênero da pessoa é: "+p.genero);
		
		teclado.close();


	}

}
