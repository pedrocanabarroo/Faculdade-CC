package pkg;
//Crie uma classe Pessoa com os atributos nome, idade e gênero. Faça leitura pelo teclado e imprima as informações da pessoa na tela.
public class Pessoa {
	public String nome;
	public int idade;
	public String genero;
}
