package pkg;

//Crie uma classe chamada Carro que possua 3 atributos: marca, modelo e anoFabricacao.
//Além disso, crie uma classe executável para criar 2 objetos do tipo Carro e exibir na tela os
//valores dos atributos criados.
//Esses valores devem ser solicitados ao usuário, por linha de execução.
public class Carro {
	public String marca;
	public String modelo;
	public int anoFabricacao;

}
