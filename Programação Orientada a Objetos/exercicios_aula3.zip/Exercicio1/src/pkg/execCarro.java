package pkg;

import java.util.Scanner;

//Crie uma classe chamada Carro que possua 3 atributos: marca, modelo e anoFabricacao.
//Além disso, crie uma classe executável para criar 2 objetos do tipo Carro e exibir na tela os
//valores dos atributos criados.
//Esses valores devem ser solicitados ao usuário, por linha de execução.
public class execCarro {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		Carro c = new Carro();
		System.out.println("Digite o nome da marca: ");
		c.marca = teclado.nextLine();
		System.out.println("Digite o modelo da marca: ");
		c.modelo = teclado.nextLine();
		System.out.println("Digite o ano de fabricação: ");
		c.anoFabricacao = teclado.nextInt();
		System.out.println("O nome da marca é: "+c.marca);
		System.out.println("O modelo é: "+c.modelo);
		System.out.println("O ano de fabricação é: "+c.anoFabricacao);
		teclado.nextLine();
		
		Carro c2 = new Carro();
		System.out.println("Digite o nome da marca: \n");
		c2.marca = teclado.nextLine();
		System.out.println("Digite o modelo da marca: \n");
		c2.modelo = teclado.nextLine();
		System.out.println("Digite o ano de fabricação: \n");
		c2.anoFabricacao = teclado.nextInt();
		System.out.println("O nome da segunda marca é: "+c2.marca);
		System.out.println("O nome do segundo modelo é: "+c2.modelo);
		System.out.println("O ano de fabricação do segundo carro é: "+c2.anoFabricacao);
		teclado.close();

	}

}
