package pkg;

public class Disciplina {
	public String nome;
	public int cargaHoraria;
	public String nomeProfessor;
	
	public void atribuiNome(String nomeDisciplina) {
		nome = nomeDisciplina;
	}
	public String recuperaNome() {
		return nome;
	}
	public void atribuiCargaHoraria(int carga) {
		cargaHoraria = carga;
	}
	public int recuperaCargaHoraria() {
		return cargaHoraria;
	}
	public void atribuiNomeProfessor(String nomeProf) {
		nomeProfessor = nomeProf;
	}
	public String recuperaNomeProfessor() {
		return nomeProfessor;
	}
}
