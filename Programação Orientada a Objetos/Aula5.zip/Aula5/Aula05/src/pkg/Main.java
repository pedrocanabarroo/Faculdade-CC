package pkg;

public class Main {

	public static void main(String[] args) {
		Disciplina d = new Disciplina();
		d.atribuiNome("Programação Orientada a Objetos");
		String nomeDisciplina;
		nomeDisciplina = d.recuperaNome();
		System.out.println("Nome recuperado: "+nomeDisciplina);
		d.atribuiCargaHoraria(50);
		
		int carga;
		carga = d.recuperaCargaHoraria();
		System.out.println("Carga Horária: "+carga);
		
		d.atribuiNomeProfessor("Girafales");
		System.out.println("Nome do professor: "+d.recuperaNomeProfessor());

	}

}
