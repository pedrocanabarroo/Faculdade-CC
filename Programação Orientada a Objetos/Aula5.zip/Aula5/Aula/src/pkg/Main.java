package pkg;

public class Main {

	public static void main(String[] args) {
	/*	exemplo1
		int[] numeros = {1, 2, 3};
	try {
		System.out.println(numeros[3]);
	} 
	catch (ArrayIndexOutOfBoundsException e) {
		System.out.println("Exceção: "+e.getMessage());
		System.out.println("Exceção: "+e.toString());
	}
	catch(Exception e) {
		System.out.println("Exceção: "+e.toString());
	}
	System.out.println("O programa segue em execução!");
	System.out.println(numeros[3]);
	System.out.println("Agora não"); */
		
		
		int a = 10;
		int b = 0;
		try {
			System.out.println(a/b);
		}
		catch (ArithmeticException e) {
			System.out.println("Erro: "+e.getMessage());
		}
		
		//exemplo3
		//String numero = "abc";
		//int valor = Integer.parseInt(numero);
	}

}
