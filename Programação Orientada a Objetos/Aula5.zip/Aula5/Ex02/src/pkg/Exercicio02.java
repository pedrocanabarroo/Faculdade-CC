package pkg;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Exercicio02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int soma, mult, sub;
		float div;
		
		try {
			System.out.println("Digite um número: ");
			int num1 = sc.nextInt();
			System.out.println("Digite outro número: ");
			int num2 = sc.nextInt();
			
			soma = num1 + num2;
			mult = num1 * num2;
			sub = num1 - num2;
			div = num1/num2;
		}
		catch (InputMismatchException e) {
			System.out.println("Erro: "+e.getMessage());
		}
		catch (ArithmeticException e) {
			System.out.println("Erro: "+e.getMessage());
		}
		
		
	}

}
