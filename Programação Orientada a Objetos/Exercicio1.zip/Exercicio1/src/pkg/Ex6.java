package pkg;

import java.util.Scanner;

public class Ex6 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Leitura dos três valores
        System.out.print("Digite o primeiro valor: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo valor: ");
        int num2 = scanner.nextInt();
        System.out.print("Digite o terceiro valor: ");
        int num3 = scanner.nextInt();
        
        // Determinação do maior valor
        int maior = num1;
        
        if (num2 > maior) {
            maior = num2;
        }
        if (num3 > maior) {
            maior = num3;
        }
        
        // Exibição do maior valor
        System.out.println("O maior valor é: " + maior);
        
        scanner.close();
    }
}