package pkg;

import java.util.Scanner;

public class Pacote2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Leitura dos dados
        System.out.print("Digite a marcação do odômetro no início do dia: ");
        double odometroInicio = scanner.nextDouble();

        System.out.print("Digite a marcação do odômetro no final do dia: ");
        double odometroFim = scanner.nextDouble();

        System.out.print("Digite a quantidade de litros de combustível gasto: ");
        double litrosGastos = scanner.nextDouble();

        System.out.print("Digite o valor total recebido dos passageiros: ");
        double valorRecebido = scanner.nextDouble();

        // Cálculos
        double totalQuilometragem = odometroFim - odometroInicio;
        double mediaConsumo = totalQuilometragem / litrosGastos;
        double custoCombustivel = litrosGastos * 4.90;
        double lucroLiquido = valorRecebido - custoCombustivel;

        // Exibição dos resultados
        System.out.println("\nRESULTADOS:");
        System.out.println("Total de quilometragem percorrida: " + totalQuilometragem + " km");
        System.out.println("Média de consumo: " + String.format("%.2f", mediaConsumo) + " km/l");
        System.out.println("Lucro líquido do dia: R$ " + String.format("%.2f", lucroLiquido));

        scanner.close();
    }
}
