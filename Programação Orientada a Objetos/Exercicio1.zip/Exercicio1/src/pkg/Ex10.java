package pkg;

import java.util.Scanner;

public class Ex10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Leitura dos dois valores
        System.out.print("Digite o primeiro valor: ");
        double num1 = scanner.nextDouble();
        System.out.print("Digite o segundo valor: ");
        double num2 = scanner.nextDouble();
        
        // Exibição do menu
        System.out.println("Escolha uma operação:");
        System.out.println("1 - Soma");
        System.out.println("2 - Subtração");
        System.out.println("3 - Multiplicação");
        System.out.println("4 - Divisão");
        System.out.print("Digite a opção desejada: ");
        int opcao = scanner.nextInt();
        
        // Estrutura switch case para operações
        switch (opcao) {
            case 1:
                System.out.println("Resultado da soma: " + (num1 + num2));
                break;
            case 2:
                System.out.println("Resultado da subtração: " + (num1 - num2));
                break;
            case 3:
                System.out.println("Resultado da multiplicação: " + (num1 * num2));
                break;
            case 4:
                if (num2 != 0) {
                    System.out.println("Resultado da divisão: " + (num1 / num2));
                } else {
                    System.out.println("Erro: Divisão por zero não permitida.");
                }
                break;
            default:
                System.out.println("Opção inválida.");
        }
        
        scanner.close();
    }
}
