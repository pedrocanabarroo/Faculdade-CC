package pkg;

import java.util.Scanner;

public class Ex8 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Leitura dos dois valores
        System.out.print("Digite o primeiro valor: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo valor: ");
        int num2 = scanner.nextInt();
        
        // Verificação de múltiplos
        if (num1 % num2 == 0 || num2 % num1 == 0) {
            System.out.println("Os números " + num1 + " e " + num2 + " são múltiplos.");
        } else {
            System.out.println("Os números " + num1 + " e " + num2 + " não são múltiplos.");
        }
        
        scanner.close();
    }
}