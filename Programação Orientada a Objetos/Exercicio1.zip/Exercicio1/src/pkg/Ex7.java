package pkg;

import java.util.Scanner;
import java.util.Arrays;

public class Ex7 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        // Leitura dos três valores
        System.out.print("Digite o primeiro valor: ");
        int num1 = scanner.nextInt();
        System.out.print("Digite o segundo valor: ");
        int num2 = scanner.nextInt();
        System.out.print("Digite o terceiro valor: ");
        int num3 = scanner.nextInt();
        
        // Armazenando os valores em um array e ordenando
        int[] numeros = {num1, num2, num3};
        Arrays.sort(numeros);
        
        // Exibição dos valores em ordem crescente
        System.out.println("Valores em ordem crescente: " + numeros[0] + ", " + numeros[1] + ", " + numeros[2]);
        
        scanner.close();
    }
}