#include <stdio.h>
#include <locale.h>
int main (){

int n, soma = 0;
int contar = 0;
float media;
setlocale(LC_ALL,"Portuguese");

printf("Digite n�meros - 0 para sair: \n");

while (n != 0){
    scanf("%i", &n);
    soma += n;
    contar ++;
}
printf("Soma = %i \n", soma);
printf("Quantidade de n�meros diferentes de 0 = %i\n",contar-1);

media = (float)soma/(contar-1);
printf("M�dia = %f", media);

return 0;



}
