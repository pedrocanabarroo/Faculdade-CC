#include <stdio.h>
#include <math.h>
#include <locale.h>


int main() {
    int base, expoente_inicial, expoente_final;
    setlocale(LC_ALL,"Portuguese");
    printf("Digite a base: ");
    scanf("%d", &base);

    printf("Digite o expoente inicial: ");
    scanf("%d", &expoente_inicial);

    printf("Digite o expoente final: ");
    scanf("%d", &expoente_final);


    printf("As pot�ncias de %d de %d a %d s�o:\n", base, expoente_inicial, expoente_final);
    for (int i = expoente_inicial; i <= expoente_final; i++) {

        double resultado = pow(base, i);

        printf("%d^%d = %.0f\n", base, i, resultado);
    }

    return 0;
}
