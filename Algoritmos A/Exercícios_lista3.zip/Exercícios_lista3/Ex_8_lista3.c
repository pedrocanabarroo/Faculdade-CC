//Ler o sal�rio de 10 funcion�rios e calcular a m�dia de sal�rios.
#include <stdio.h>
#include <locale.h>

#include <stdio.h>

int main() {

    setlocale(LC_ALL,"Portuguese");
    float salario, soma_salarios = 0.0;
    int i;


    for (i = 1; i <= 10; i++) {
        printf("Digite o sal�rio do funcion�rio %d: ", i);
        scanf("%f", &salario);
        soma_salarios += salario;
    }


    float media_salarios = soma_salarios / 10;

    printf("A m�dia dos sal�rios dos 10 funcion�rios �: %.2f\n", media_salarios);

    return 0;
}





