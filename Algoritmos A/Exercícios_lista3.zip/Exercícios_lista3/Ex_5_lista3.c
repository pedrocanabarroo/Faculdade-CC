#include <stdio.h>
#include <locale.h>

int main (){

int fat = 1, n, x;
setlocale(LC_ALL,"Portuguese");

printf("Digite um n�mero: ");
scanf("%i", &n);

for (x = n; x >= 1; x--){
    fat = fat * x;
}
printf("Fatorial de %d = %d\n", n, fat);

return 0;
}
