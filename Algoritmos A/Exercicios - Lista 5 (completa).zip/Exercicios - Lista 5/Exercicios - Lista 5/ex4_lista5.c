/*Em um concurso, a identifica��o das cadeiras da sala s�o armazenadas em uma matriz. Considere que
existem 6 filas de cadeiras na sala e cada fila possui 7 cadeiras. Desenvolva um algoritmo com uma matriz
para armazenar a identifica��o das cadeiras que � informada pelo usu�rio. A matriz deve ser exibida. Ap�s,
apresentar ao usu�rio a mensagem: �Insira o n�mero da fila:� para que o algoritmo leia o n�mero de uma
fila e mostra a identifica��o de todas as cadeiras desta fila*/

#include <stdio.h>
#include <locale.h>
#include <stdlib.h>

int main(){

    int sala[6][7], i, j, n;

    setlocale(LC_ALL,"Portuguese");

    printf("\nPosi��o das cadeiras na sala\n");
    for(i = 0; i < 6; i++){
        for(j = 0; j < 7; j++){
            sala[i][j] = rand()%50;
            printf("%d\t", sala[i][j]);
        }
        printf("\n");
    }

    printf("Insira o n�mero da fila: ");
    scanf("%d", &n);

    printf("Fila escolhida %d\n", n);
    for (j = 0; j < 7; j++){
        printf("%d\t",sala[n-1][j]);
    }

return 0;

}
