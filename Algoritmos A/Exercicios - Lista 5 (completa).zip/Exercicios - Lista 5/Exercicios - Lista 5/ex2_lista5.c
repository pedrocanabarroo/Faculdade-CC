/*Escreva um programa em C que gere os elementos de uma matriz quadrada 5 x 5 e:
Exiba todos os elementos da matriz
Exiba os elementos da diagonal principal da matriz
Calcule e mostre a m�dia dos valores da diagonal principal da matriz
Calcule e mostre a m�dia dos elementos da matriz
Encontre e mostre na tela os elementos que est�o acima da m�dia, com sua posi��o (�ndice de linha e
coluna)*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main(){

    int m[5][5], i, j;
    int somaD = 0, somaM = 0;
    int x, linhaX, colunaX;
    float mediaD, mediaM;

    setlocale(LC_ALL,"Portuguese");

    //matriz geradora
    printf("Matriz 5x5\n");

    for(i = 0; i < 5; i++){
        for(j = 0; j < 5; j++){
            m[i][j] = rand()%50;
            printf("%d\t", m[i][j]);
        }
        printf("\n");
    }

    //diagonal principal
    printf("\nDiagonal principal: ");

    for(i = 0; i < 5; i++){
        printf("%d\t", m[i][i]);
    }

    //media da diagonal principal

    printf("\n");
    printf("\nM�dia da diagonal principal: \n");
    for(i = 0; i < 5; i++){
        somaD += m[i][i];
    }
    mediaD = (float) somaD/5;
    printf("A soma de todos os elementos da diagonal �: %d", somaD);
    printf("\nA m�dia �: %f", mediaD);

    //media da matriz
    printf("\n");
    printf("\nM�dia da matriz principal: \n");
    for(i = 0; i < 5; i++){
        for(j = 0; j < 5; j++){
            somaM += m[i][j];
        }
    }
    mediaM = (float) somaM/25;
    printf("A soma de todos os elementos da matriz �: %d", somaM);
    printf("\nA m�dia �: %f", mediaM);

    //mostrar os que est�o acima da media

    printf("\n");
    printf("Valores acima da m�dia s�o: \n");
    for(i = 0; i < 5; i++){
        for(j = 0; j < 5; j++){
            if(m[i][j] > mediaM){
                printf("%d\t", m[i][j]);
            }
        }
    }
return 0;
}
