/*Ler uma matriz 3 x 2 e um n�mero informados pelo usu�rio. O algoritmo deve gerar uma nova matriz que �
o resultado da multiplica��o do n�mero pela matriz lida.*/

#include <stdio.h>
#include <locale.h>

int main(){

    int i, j, n, m[3][2], mult[3][2];

    setlocale(LC_ALL,"Portuguese");

    printf("Informe os valores da matriz 3x2\n");
    for (i = 0; i < 3; i++){
        for (j = 0; j < 2; j++){
            printf("N�mero [%d][%d] = ", i, j);
            scanf("%d", &m[i][j]);
        }
    }

    printf("Informe o valor para multiplicar a matriz: ");
    scanf("%d", &n);

    printf("\nMatriz modificada\n");
    for(i = 0; i < 3; i++){
        for(j = 0; j < 2; j++){
            mult[i][j] = n * m[i][j];
            printf("%d\t", mult[i][j]);
        }
        printf("\n");
    }

return 0;
}
