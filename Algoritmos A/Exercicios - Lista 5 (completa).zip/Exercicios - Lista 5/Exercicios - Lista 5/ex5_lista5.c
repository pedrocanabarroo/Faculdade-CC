/*Em cada �rea, ele aplicou diferentes formas de tratamento do solo e das plantas (insumos, pesticidas...).
Ap�s realizar a colheita, ele armazenou os dados da produtividade (quantidade de sacos/hectare) de cada
uma das �reas.
a) Utilize uma matriz para armazenar os valores da produtividade de cada �rea
b) Leia os dados armazenados em cada �rea
c) Calcule e exiba a m�dia de produtividade da lavoura
d) Identifique e mostre as �reas que produziram acima da m�dia e abaixo da m�dia*/

#include <stdio.h>
#include <locale.h>

int main(){

    int area[2][4], i, j;
    int somaL = 0;
    float mediaL;

    setlocale(LC_ALL,"Portuguese");

    printf("Leitura da produtividade da lavoura\n");

    for(i = 0; i < 2; i++){
        for(j = 0; j < 4; j++){
            printf("Produtividade da �rea em metros quadrados [%d][%d] = ", i, j);
            scanf("%d", &area[i][j]);
        }
        printf("\n");
    }

    printf("\n");
    for(i = 0; i < 2; i++){
        for(j = 0; j < 4; j++){
            somaL += area[i][j];
        }
    }

    mediaL = (float) somaL/8;
    printf("A soma de toda produtividade da lavoura �: %d\n", somaL);
    printf("\nA m�dia produzida na lavoura �: %f\n", mediaL);

    printf("\n");
    for(i = 0; i < 2; i++){
        for(j = 0; j < 4; j++){
            if(area[i][j] > mediaL){
                printf("\n");
                printf("\nValores acima da produtividade: %d\t", area[i][j]);
            }
            else{
                printf("\n");
                printf("\nValores abaixo da produtividade: %d\t", area[i][j]);
            }
        }
    }

return 0;


}
