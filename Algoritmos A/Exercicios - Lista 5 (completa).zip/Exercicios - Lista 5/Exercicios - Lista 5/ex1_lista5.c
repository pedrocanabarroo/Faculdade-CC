//Ler uma matriz informada pelo usu�rio, com tamanho 3 x 5. Mostrar seus elementos.
#include <stdio.h>

int main(){

    int i, j, m[3][5];

    printf("Informe os elementos da matriz 3x5\n ");
    for(i = 0; i < 3; i++){
        for(j = 0; j < 5; j++){
            printf("Numero [%d][%d] = ", i, j);
            scanf("%d", &m[i][j]);
        }
        printf("\n");
    }

    for(i = 0; i < 3; i++){
        for(j = 0; j < 5; j++){
            printf("%d\t", m[i][j]);
        }

        printf("\n");
    }

return 0;
}
