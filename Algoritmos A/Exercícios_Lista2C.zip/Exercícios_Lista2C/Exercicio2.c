//Desenvolva um programa para ler um n�mero inteiro de 1 a 12, que corresponde a um dos
//meses do ano, e outro n�mero inteiro que corresponde ao ano. Encontre e mostre o n�mero de dias
//referente ao m�s informado.
#include <stdio.h>
#include <locale.h>
#include <math.h>
int main(){

int mes, ano;

setlocale(LC_ALL, "Portuguese");
printf("Digite um m�s (de 1 a 12): ");
scanf("%i", &mes);
printf("Digite um ano: ");
scanf("%i", &ano);

switch(mes){
    case 1: //janeiro
    case 3: //mar�o
    case 5: //maio
    case 7: //julho
    case 8: //agosto
    case 10: //outubro
    case 12: //dezembro
        printf("O m�s %i tem 31 dias.\n", mes);
        break;
    case 4: //abril
    case 6: //junho
    case 9: //setembro
    case 11: //novembro
        printf("O m�s %i tem 30 dias.\n", mes);
        break;
    case 2: //fevereiro
        if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)){
            printf("O m�s de fevereiro no ano %i tem 29 dias.\n", ano);
        }else{
            printf("O m�s de fevereiro no ano %i tem 28 dias.\n", ano);
        }
        break;
    default:
        printf("M�s inv�lido! Por favor digite um m�s entre 1 a 12.\n");
        break;
}

return 0;

}












