//Escreva um programa que pede para o usu�rio digitar um n�mero que corresponda a um
//dia da semana. O programa deve apresentar na tela o nome do dia. Utilize o comando
//switch
#include <stdio.h>
#include <locale.h>
int main(){

setlocale(LC_ALL,"Portuguese");

int dia;

printf("Digite um dia da semana (de 1 a 7): ");
scanf("%i", &dia);

switch(dia){
    case 1:
        printf("O dia � domingo!");
        break;
    case 2:
        printf("O dia � segunda - feira!");
        break;
    case 3:
        printf("O dia � ter�a - feira!");
        break;
    case 4:
        printf("O dia � quarta - feira!");
        break;
    case 5:
        printf("O dia � quinta - feira!");
        break;
    case 6:
        printf("O dia � sexta - feira!");
        break;
    case 7:
        printf("O dia � s�bado!");
        break;
    default: printf("Op��o inv�lida!");
    break;
}

return 0;

}
