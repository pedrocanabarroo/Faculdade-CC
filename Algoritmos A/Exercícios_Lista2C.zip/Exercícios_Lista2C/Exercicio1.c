//13% para os sal�rios inferiores ou iguais a R$ 2000,00;
//11% para os sal�rios situados entre R$ 2000,0 e R$ 4000,00 (inclusive);
//9 % para os sal�rios entre R$ 4000,00 e R$ 8000,00 (inclusive); e
//7% para os demais sal�rios.
//Desenvolva um programa que receba o sal�rio atual de um funcion�rio e forne�a o valor do
//seu novo sal�rio. Mostre tamb�m o b�nus (em reais e em %).
#include <stdio.h>
#include <locale.h>
int main(){

float salarioAntigo, novoSalario, valorBonus;
setlocale(LC_ALL,"Portuguese");
printf("Digite o seu sal�rio atual: R$");
scanf("%f", &salarioAntigo);

if (salarioAntigo <= 2000){
    valorBonus = salarioAntigo * 0.13;
    novoSalario = salarioAntigo + valorBonus;
    printf("O novo sal�rio ser� de: R$ %.2f\n",novoSalario);
    printf("O b�nus ser� de 13%%\n");
    printf("O valor do acr�scimo do b�nus ser� de: R$ %.2f",valorBonus);
}   else if (salarioAntigo <= 4000){
        valorBonus = salarioAntigo * 0.11;
        novoSalario = salarioAntigo + valorBonus;
        printf("O novo sal�rio ser� de: R$ %.2f\n",novoSalario);
        printf("O b�nus ser� de 11%%\n");
        printf("O valor do acr�scimo do b�nus ser� de: R$ %.2f",valorBonus);
}       else if (salarioAntigo <= 8000){
            valorBonus = salarioAntigo * 0.09;
            novoSalario = salarioAntigo + valorBonus;
            printf("O novo sal�rio ser� de: R$ %.2f\n",novoSalario);
            printf("O b�nus ser� de 9%%\n");
            printf("O valor do acr�scimo do b�nus ser� de: R$ %.2f",valorBonus);
}           else{
                valorBonus = salarioAntigo * 0.07;
                novoSalario = salarioAntigo + valorBonus;
                printf("O novo sal�rio ser� de: R$ %.2f\n",novoSalario);
                printf("O b�nus ser� de 7%%\n");
                printf("O valor do acr�scimo do b�nus ser� de: R$ %.2f",valorBonus);
}

return 0;
}
