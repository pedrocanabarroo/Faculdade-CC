#include <stdio.h>
#include <locale.h>

int main() {
    float altura, peso, peso_ideal, diferenca;
    char sexo;
    setlocale(LC_ALL,"Portuguese");

    printf("Digite a altura (em metros): ");
    scanf("%f", &altura);
    printf("Digite o peso (em kg): ");
    scanf("%f", &peso);
    printf("Digite o sexo (M para masculino, F para feminino): ");
    scanf(" %c", &sexo);

    if (sexo == 'M' || sexo == 'm') {
        peso_ideal = (72.7 * altura) - 58;
    } else if (sexo == 'F' || sexo == 'f') {
        peso_ideal = (62.1 * altura) - 44.7;
    } else {
        printf("Sexo inv�lido!\n");
        return 1;
    }

    diferenca = peso - peso_ideal;

    printf("Peso ideal: %.2f kg\n", peso_ideal);
    if (diferenca > 0) {
        printf("Voc� est� acima do peso ideal em %.2f kg.\n", diferenca);
    } else if (diferenca < 0) {
        printf("Voc� est� abaixo do peso ideal em %.2f kg.\n", -diferenca);
    } else {
        printf("Voc� est� no peso ideal!\n");
    }

    return 0;
}
