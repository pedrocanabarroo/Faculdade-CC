#include <stdio.h>
#include <locale.h>

int main() {
    float lado1, lado2, lado3;
    setlocale(LC_ALL,"Portuguese");

    printf("Digite os tr�s lados do tri�ngulo: ");
    scanf("%f %f %f", &lado1, &lado2, &lado3);

    if (lado1 < lado2 + lado3 && lado2 < lado1 + lado3 && lado3 < lado1 + lado2) {
        if (lado1 == lado2 && lado2 == lado3) {
            printf("O tri�ngulo � equil�tero.\n");
        } else if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3) {
            printf("O tri�ngulo � is�sceles.\n");
        } else {
            printf("O tri�ngulo � escaleno.\n");
        }
    } else {
        printf("Os valores informados n�o formam um tri�ngulo.\n");
    }

    return 0;
}

