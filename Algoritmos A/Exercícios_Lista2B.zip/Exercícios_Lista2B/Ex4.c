#include <stdio.h>
#include <locale.h>
int main(){

float salarioMensal, salarioLiquido, valorDesconto;

setlocale(LC_ALL,"Portuguese");
printf("Qual o valor do sal�rio mensal: R$");
scanf("%f", &salarioMensal);

if(salarioMensal <= 965.67){
    valorDesconto = salarioMensal * 0.08;
    salarioLiquido = salarioMensal - valorDesconto;
    printf("O percentual descontado foi de 8%%\n");
    printf("O sal�rio l�quido ser� de: R$ %.2f\n",salarioLiquido);
    printf("O valor em reais do desconto ser� de: R$ %.2f",valorDesconto);
}   else if(salarioMensal <= 1609.45){
        valorDesconto = salarioMensal * 0.09;
        salarioLiquido = salarioMensal - valorDesconto;
        printf("O percentual descontado foi de 9%%\n");
        printf("O sal�rio l�quido ser� de: R$ %.2f\n",salarioLiquido);
        printf("O valor em reais do desconto ser� de: R$ %.2f",valorDesconto);
 }       else{
            valorDesconto = salarioMensal * 0.11;
            salarioLiquido = salarioMensal - valorDesconto;
            printf("O percentual descontado foi de 11%%\n");
            printf("O sal�rio l�quido ser� de: R$ %.2f\n",salarioLiquido);
            printf("O valor em reais do desconto ser� de: R$ %.2f",valorDesconto);
        }
return 0;



}







