//Considere a tabela de Al�quota de Imposto de Renda (IR) a seguir. Desenvolva um
//algoritmo para ler um valor de sal�rio mensal, mostrar o % da al�quota do imposto de Renda e o
//valor em R$ da al�quota.
//1.566,61 -
//De 1.566,62 at� 2.347,85 %7,5
//De 2.347,86 at� 3.130,51 %15,0
//De 3.130,52 at� 3.911,63 %22,5
//Acima de 3.911,64 %27,5

#include <stdio.h>
#include <locale.h>

int main(){

setlocale(LC_ALL,"Portuguese");
float salarioMensal, valorAliquota, salarioLiquido;

printf("Qual o valor do sal�rio mensal? R$");
scanf("%f", &salarioMensal);



if (salarioMensal <= 1566.61){
    printf("N�o h� desconto para esse valor");
}else if(salarioMensal <= 2347.85){
    valorAliquota = salarioMensal * 0.075;
    salarioLiquido = salarioMensal - valorAliquota;
    printf("A porcentagem descontada foi de 7,5%%\n");
    printf("O valor do desconto da al�quota foi de: R$ %.2f\n",valorAliquota);
    printf("O sal�rio l�quido ser� de: R$ %.2f", salarioLiquido);
}   else if(salarioMensal <= 3130.51){
        valorAliquota = salarioMensal * 0.15;
        salarioLiquido = salarioMensal - valorAliquota;
        printf("A porcentagem descontada foi de 15%%\n");
        printf("O valor do desconto da al�quota foi de: R$ %.2f\n",valorAliquota);
        printf("O sal�rio l�quido ser� de: R$ %.2f", salarioLiquido);
}           else if(salarioMensal <= 3911.63){
                valorAliquota = salarioMensal * 0.225;
                salarioLiquido = salarioMensal - valorAliquota;
                printf("A porcentagem descontada foi de 22,5%%\n");
                printf("O valor do desconto da al�quota foi de: R$ %.2f\n",valorAliquota);
                printf("O sal�rio l�quido ser� de: R$ %.2f", salarioLiquido);
}                   else{
                        valorAliquota = salarioMensal * 0.275;
                        salarioLiquido = salarioMensal - valorAliquota;
                        printf("A porcentagem descontada foi de 27,5%%\n");
                        printf("O valor do desconto da al�quota foi de: R$ %.2f\n",valorAliquota);
                        printf("O sal�rio l�quido ser� de: R$ %.2f", salarioLiquido);

}

return 0;

}













