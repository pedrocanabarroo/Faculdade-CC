//Ler uma matriz 2x3, multiplicar seus elementos por um n�mero informado
//pelo usu�rio e mostrar a matriz modificada.

#include <stdio.h>

int main(){
    //declara��o de matriz 2x3
    int i, j, n, num[2][3], mult[2][3];

    //leitura da matriz
    printf("Informe os elementos da matriz 2x3\n ");
    for(i = 0; i < 2; i++)
        for(j = 0; j < 3; j++){
            printf("numero [%d][%d] = ", i, j);
            scanf("%d", &num[i][j]);
        }

    //multiplica��o por um n�mero

    printf("Informe um numero para multiplicar: ");
    scanf("%d", &n);


    printf("\nMatriz modificada\n");
    for(i = 0; i < 2; i++){
        for(j = 0; j < 3; j++){
            mult[i][j] = n * num[i][j];
            printf("%d\t", mult[i][j]);
        }
        printf("\n");
    }
return 0;
}
