#include <stdio.h>
#include <locale.h>

int main(){

    //declara��o de matriz, 5x3
    float nota[5][3];
    int i, j, n;

    setlocale(LC_ALL,"Portuguese");

    //leitura da matriz
    for (i = 0; i < 5; i++)
        for(j = 0; j < 3; j++){
            printf("Nota [%d][%d] = ", i, j);
            scanf("%f", &nota[i][j]);
        }

    //exibi��o da matriz na tela
    printf("\nMatriz de notas\n");
    for(i = 0; i < 5; i++){
        for(j = 0; j < 3; j++){
            printf("%.1f\t", nota[i][j]);
        }
        printf("\n");
    }

    //para selecionar uma linha somente
    printf("Insira o n�mero do aluno: ");
    scanf("%d", &n);

    printf("Notas do aluno %d\n", n);
    for (j = 0; j < 3; j++){
        printf("%.1f\t",nota[n-1][j]);
    }

return 0;
}
