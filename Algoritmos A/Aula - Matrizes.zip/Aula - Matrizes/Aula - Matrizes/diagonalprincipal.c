#include <stdio.h>
#include <stdlib.h>

int main(){

    int m[4][4], i, j;
    int x, linhaX, colunaX;

    printf("Matriz 4x4\n");
    for(i = 0; i < 4; i++){
        for(j = 0; j < 4; j++){
            m[i][j] = rand()%50;
            printf("%d\t", m[i][j]);
        }
        printf("\n");
    }

    //mostrar diagonal principal
    printf("Diagonal principal: ");

    for(i = 0; i < 4; i++){
        printf("%d\t", m[i][i]);
    }

    //maior valor da matriz e sua posi��o
    x = m[0][0];
    for(i = 0; i < 4; i++){
        for(j = 0; j < 4; j++){
            if(m[i][j] > x){
                x = m[i][j];
                linhaX = i;
                colunaX = j;
            }
        }

    }

    printf("\nMaior valor = %d\n", x);
    printf("Na linha %d e na coluna %d", linhaX, colunaX);


    return 0;
}
