#include <stdio.h>
#include <locale.h>

int main() {
    int a, b, resto;
    setlocale(LC_ALL, "Portuguese");

    // Leitura dos valores das vari�veis
    printf("Digite o primeiro valor inteiro: ");
    scanf("%d", &a);
    printf("Digite o segundo valor inteiro: ");
    scanf("%d", &b);

    // Calcula o resto da divis�o
    resto = a % b;

    // Verifica as condi��es
    if (resto == 1) {
        // Se o resto for 1, mostra a soma das vari�veis mais o resto
        printf("A soma das vari�veis mais o resto da divis�o �: %d\n", a + b + resto);
    } else if (resto == 2) {
        // Se o resto for 2, mostra se os valores s�o pares ou �mpares
        if (a % 2 == 0) {
            printf("O primeiro valor � par.\n");
        } else {
            printf("O primeiro valor � �mpar.\n");
        }

        if (b % 2 == 0) {
            printf("O segundo valor � par.\n");
        } else {
            printf("O segundo valor � �mpar.\n");
        }
    } else if (resto == 3) {
        // Se o resto for 3, multiplica a soma dos valores pelo primeiro valor
        printf("A soma dos valores multiplicada pelo primeiro valor �: %d\n", (a + b) * a);
    } else if (resto == 4) {
        // Se o resto for 4, divide a soma dos n�meros pelo segundo valor, se o segundo valor for diferente de zero
        if (b != 0) {
            printf("A soma dos valores dividida pelo segundo valor �: %.2f\n", (float)(a + b) / b);
        } else {
            printf("N�o � poss�vel dividir por zero.\n");
        }
    } else {
        // Em qualquer outra situa��o, mostra o quadrado dos n�meros lidos
        printf("O quadrado dos n�meros lidos s�o: %d e %d\n", a * a, b * b);
    }

    return 0;
}




