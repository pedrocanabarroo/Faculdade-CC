#include <stdio.h>
int main(){

int v1, v2, v3;

printf("Leia os tres valores: \n");
scanf("%i", &v1);
scanf("%i", &v2);
scanf("%i", &v3);

if (v1 > v2 && v1 > v3) {
    printf("O maior numero eh: %i", v1);
}   else if (v2 > v1 && v2 > v3){
        printf("O maior numero eh: %i", v2);
}       else{
            printf("O maior numero eh: %i", v3);
}

return 0;

}
