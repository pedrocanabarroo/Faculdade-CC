#include <stdio.h>
#include <locale.h>
int main(){

int n, a, b, soma, quad;
setlocale(LC_ALL,"Portuguese");
printf("Digite um n�mero (1000 a 9999): ");
scanf("%d", &n);

if(n >= 1000 && n <= 9999){
    a = n/100;
    b = n%100;
    soma = a+b;
    quad = soma*soma;
    if(quad == n){
        printf("O numero %i obedece a regra.\n", n);
}        else{
            printf("O n�mero %i n�o obedece a regra!", n);
}
}
else{
    printf("O n�mero deve estar no intervalo [1000, 9999]");
}
return 0;
}
