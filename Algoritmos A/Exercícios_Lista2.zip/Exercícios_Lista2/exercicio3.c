//Escreva um algoritmo para ler a quantidade de horas aula
//trabalhadas por dois professores e o valor por hora recebido
//por cada um deles. Mostrar na tela qual dos professores tem
//o maior sal�rio total.
#include <stdio.h>
int main(){

int horasAula1, horasAula2;
float valorHora1, valorHora2, salarioTotal1, salarioTotal2;

printf("Digite as horas trabalhadas pelo professor 1: ");
scanf("%i", &horasAula1);
printf("Digite o valor por hora recebido pelo professor 1: R$");
scanf("%f", &valorHora1);

printf("Digite as horas trabalhadas pelo professor 2: ");
scanf("%i", &horasAula2);
printf("Digite o valor por hora recebido pelo professor 2: R$");
scanf("%f", &valorHora2);

salarioTotal1 = horasAula1 * valorHora1;
salarioTotal2 = horasAula2 * valorHora2;

if (salarioTotal1 > salarioTotal2) {
        printf("O primeiro professor tem o maior salario total: R$ %.2f\n", salarioTotal1);
    } else if (salarioTotal2 > salarioTotal1) {
        printf("O segundo professor tem o maior salario total: R$ %.2f\n", salarioTotal2);
    } else {
        printf("Ambos os professores tem o mesmo salario total: R$ %.2f\n", salarioTotal1);
    }
return 0;
}
















