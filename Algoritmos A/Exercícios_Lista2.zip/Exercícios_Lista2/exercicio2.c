#include <stdio.h>
int main(){

int v1, v2, v3, v4;
float media;

printf("Digite as 4 notas: ");
scanf("%i", &v1);
scanf("%i", &v2);
scanf("%i", &v3);
scanf("%i", &v4);

media = (v1 + v2 + v3 + v4)/4;

if (v1 > media){
    printf("a nota %i eh maior que a media %f\n", v1, media);
}
if (v2 > media){
    printf("a nota %i eh maior que a media %f\n", v2, media);
}
if (v3 > media){
    printf("a nota %i eh maior que a media %f\n", v3, media);
}
if (v4 > media){
    printf("a nota %i eh maior que a media %f\n", v4, media);
}


return 0;



}
