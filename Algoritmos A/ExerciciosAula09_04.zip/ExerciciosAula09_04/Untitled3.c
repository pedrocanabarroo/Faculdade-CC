#include <stdio.h>
#include <locale.h>
int main(){

int n1, n2, q, aux;

printf("Informe o intervalo: ");
scanf("%d %d", &n1, &n2);

if (n1>n2){
    aux = n1;
    n1 = n2;
    n2 = aux;
}
for (q=n1; q<=n2; q++){
    if(q%2==0)
        printf("%d \t", q);
}
return 0;
}
