#include <stdio.h>
#include <locale.h>
int main(){

int n1, n2, q;

printf("Informe o intervalo: ");
scanf("%d %d", &n1, &n2);

for(q=n1; q<=n2; q++){
    if(q%2==0)
        printf("%d\t",q);
}
return 0;
}
