//Vari�vel acumuladora
#include <stdio.h>
#include <locale.h>
int main (){

setlocale(LC_ALL,"Portuguese");
int qtdchuva, totalchuva = 0;
int d = 1;
float mediachuva;
printf("Insira a quantidade de chuva em cada dia do m�s de Mar�o: \n");

while (d<=31){
    printf("Dia: %d\n", d);
    scanf("%d", &qtdchuva);
    totalchuva += qtdchuva;
    d++;
}
printf("Total chuva = %i\n", totalchuva);
mediachuva = (float)totalchuva/31;
printf("M�dia de chuva %f\n", mediachuva);
return 0;







}
