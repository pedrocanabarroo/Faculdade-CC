#include <stdio.h>

// Ler 2 valores e informar qual � o maior
int main(){

    float a, b;

printf("Digite o primeiro numero: \n");
scanf("%f", &a);
printf("Digite o segundo numero: \n");
scanf("%f", &b);

if (a > b){
    printf("O primeiro numero eh maior que o segundo.", a);
} else if (a < b){
    printf("O segundo numero eh maior que o primeiro", b);
} else {
    printf("Os valores sao iguais. ");
}
    return 0;
}
