//escreva um algoritmo para ler dois valores inteiros e escrever na tela a
//diferen�a do maior para o menor.
#include <stdio.h>
#include <math.h>
int main(){

float a, b, resultado;

printf("Digite os numeros: \n");
scanf("%f", &a);
scanf("%f", &b);

if (a > b){
    resultado = a - b;
    printf("A diferenca eh de: %f", resultado);

} else if (b > a) {
    resultado = b - a;
    printf("A diferenca eh de: %f", resultado);

} else {
    printf("OS numeros sao iguais");
}

return 0;


}
