//Calcule a media final de um aluno, considerando que esta � a media de tres
//notas. Inclua a seguinte condi��o. se a m�dia for maior ou igual a 6,0,
//o aluno est�ra aprovado, caso contrario reprovado.
#include <stdio.h>
int main(){

float a, b, c, media;

printf("Digite as notas: \n");
scanf("%f", &a);
scanf("%f", &b);
scanf("%f", &c);

media = (a + b + c)/3;

if (media >= 6.0){
    printf("O aluno foi aprovado! ");
} else {
    printf("O aluno foi reprovado. ");
}

return 0;
}
