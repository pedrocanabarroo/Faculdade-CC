#include <stdio.h>
#include <math.h>
int main(){

float salarioFixo, acrescimo, salario_final, comissao_por_carro, v_total, comissao_vendas;
int cod_vendedor, carro;


//leitra dos dados
printf("Digite o codigo do vendedor: ");
scanf("%i", &cod_vendedor);

printf("Digite o salario do vendedor: ");
scanf("%f", &salarioFixo);

printf("Digite o numero de carros que o vendedor vendeu no mes: ");
scanf("%i", &carro);

printf("Digite o valor da comissao por carro: ");
scanf("%f", &comissao_por_carro);

printf("O valor total das vendas: ");
scanf("%f", &v_total);

comissao_vendas = v_total * 0.04;
salario_final = salarioFixo + (carro * comissao_por_carro) + comissao_vendas;

printf("Codigo do vendedor: %i\n", cod_vendedor);
printf("Salario final: R$ %.2f\n", salario_final);

return 0;

}
