#include <stdio.h>
#include <math.h>
int main (){

float x, y, raiz, resultado, frac1, frac2;

printf("Qual o valor de x? ");
scanf("%f", &x);

printf("Qual o valor de y? ");
scanf("%f", &y);

raiz = sqrt(x+y);
frac1 = (x*y)/(2*x);
frac2 = (x*x)/4;

resultado = raiz + frac1 + (3*3) + frac2;

printf("O resultado: = %.2f", resultado);

return 0;

}
