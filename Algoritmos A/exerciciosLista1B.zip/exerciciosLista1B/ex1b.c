#include <stdio.h>
#include <math.h>
int main (){

float x, pot_x, raiz_x, resultado;

printf("Qual o valor de X? ");
scanf("%f", &x);

pot_x = (pow(x,x+1)*3)/2;
raiz_x = sqrt(x+1);

resultado = x * x + pot_x + raiz_x;

printf("O resultado: = %.2f", resultado);

return 0;
}
