#include <stdio.h>
//Escreva um algoritmo que leia a matrícula, o valor da hora e o número de horas trabalhadas por um
//empregado. O algoritmo deve escrever a matrícula e o salário líquido do empregado, calculado
//conforme as seguintes regras:
// o salário bruto mensal é o produto das horas trabalhadas pelo valor da hora;
// sobre o salário bruto mensal é aplicado um desconto de 9% referente ao INSS;
// sobre o salário bruto mensal é aplicado um desconto de 8% referente ao FGTS;
// o salário líquido é o salário bruto mensal menos os encargos (descontos).
int main(){

int matricula, num_horas_trab;
float valor_hora, sal_liquido, sal_bruto, desc_inss, desc_fgts, sal_inss, sal_fgts;

printf("Matricula funcionario: ");
scanf("%i", &matricula);

printf("O valor da hora: R$ ");
scanf("%f", &valor_hora);

printf("O numero de horas trabalhadas: ");
scanf("%i", &num_horas_trab);

desc_fgts = 0.08;
desc_inss = 0.09;
sal_bruto = num_horas_trab * valor_hora;
sal_fgts = sal_bruto * desc_fgts;
sal_inss = sal_bruto * desc_inss;
sal_liquido = sal_bruto - sal_fgts - sal_inss;

printf("O valor do salario bruto: R$ %.2f\n", sal_bruto);
printf("O desconto do fgts foi de: R$ %.2f e o desconto do inss foi de: R$ %.2f\n", sal_fgts, sal_inss);

printf("O salario liquido: R$ %.2f\n", sal_liquido);

return 0;

}

