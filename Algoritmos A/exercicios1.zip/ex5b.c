#include <stdio.h>
//A comiss�o de formatura de um curso est� organizando a festa de formaturra da sua turma e levantou as
//seguintes informa��es:
//custo do sal�o (capacidade de 800 pessoas, com mesas de 4 pessoas): R$ 2.000,00
//custo da sonoriza��o: R$ 500,00
//custo da decora��o: R$ 800,00
//Al�m destes custos, que dever�o ser rateados igualmente entre os formandos, h� custos cuja divis�o �
//proporcional ao n�mero de convidados do formando. S�o eles:
//seguran�a: necess�rio um seguran�a para cada 80 pessoas na festa
//gar�om: um gar�om consegue atender 48 pessoas
//bebida
//Escreva um algoritmo que leia a matr�cula de cada um dos 5 formandos com seus respectivos n�meros
//de convidados. Ele tamb�m deve ler os custos de um seguran�a, de um gar�om e da bebida. O algoritmo
//deve calcular e escrever, para cada formando, o custo da festa para ele.


#include <stdio.h>

int main() {
    int matricula, num_convidados;
    int custo_sala = 2000, custo_sonorizacao = 500, custo_decoracao = 800;
    int custo_seguranca, custo_garcom, custo_bebida;
    int num_segurancas, num_garcons, total_convidados = 0;
    int custo_fixo_total, custo_seguranca_total, custo_garcom_total, custo_bebida_total;
    int i;

    // Leitura dos custos unit�rios
    printf("Digite o custo de um seguranca: R$ ");
    scanf("%d", &custo_seguranca);

    printf("Digite o custo de um garcom: R$ ");
    scanf("%d", &custo_garcom);

    printf("Digite o custo da bebida por pessoa: R$ ");
    scanf("%d", &custo_bebida);

    // Leitura dos dados dos 5 formandos
    for (i = 1; i <= 5; i++) {
        printf("\nDigite a matricula do formando %d: ", i);
        scanf("%d", &matricula);
        printf("Digite o numero de convidados do formando %d: ", i);
        scanf("%d", &num_convidados);
        total_convidados += num_convidados;
    }

    // C�lculo do custo total fixo
    custo_fixo_total = custo_sala + custo_sonorizacao + custo_decoracao;

    // C�lculo do n�mero de seguran�as e gar�ons necess�rios
    num_segurancas = (total_convidados / 80) + (total_convidados % 80 != 0); // 1 seguran�a para cada 80 pessoas
    num_garcons = (total_convidados / 48) + (total_convidados % 48 != 0); // 1 gar�om para cada 48 pessoas

    // C�lculo do custo vari�vel
    custo_seguranca_total = num_segurancas * custo_seguranca;
    custo_garcom_total = num_garcons * custo_garcom;
    custo_bebida_total = total_convidados * custo_bebida;

    // C�lculo do custo individual fixo
    int custo_fixo_individual = custo_fixo_total / 5;

    // Exibi��o do custo para cada formando
    for (i = 1; i <= 5; i++) {
        printf("\nDigite a matricula do formando %d: ", i);
        scanf("%d", &matricula);
        printf("Digite o numero de convidados do formando %d: ", i);
        scanf("%d", &num_convidados);

        int custo_individual = custo_fixo_individual + (custo_seguranca_total + custo_garcom_total + custo_bebida_total) * num_convidados / total_convidados;
        printf("\nCusto da festa para o formando %d (Matricula: %d): R$ %d", i, matricula, custo_individual);
    }

    return 0;
}















