//Uma loja vende bicicletas com um acr�scimo de 50% sobre o pre�o de custo. Ela paga a cada vendedor
//2 sal�rios m�nimos mensais, mais uma comiss�o de 15% sobre o pre�o de custo de cada bicicleta
//vendida, dividida igualmente entre eles. Desenvolva um algoritmo que leia o n�mero de empregados da
//loja, o valor do sal�rio m�nimo, o pre�o de custo de cada bicicleta e o n�mero de bicicletas vendidas,
//calcule e mostre: o sal�rio que cada empregado receber� e o lucro l�quido da loja.
#include <stdio.h>

int main() {
    int numEmpregados, numBicicletasVendidas;
    float salarioMinimo, precoCusto, comissaoPorVendedor, lucroBruto, lucroLiquido, salarioEmpregado;

    // Leitura dos dados
    printf("Digite o numero de empregados da loja: ");
    scanf("%d", &numEmpregados);

    printf("Digite o valor do salario minimo: ");
    scanf("%f", &salarioMinimo);

    printf("Digite o preco de custo de cada bicicleta: ");
    scanf("%f", &precoCusto);

    printf("Digite o numero de bicicletas vendidas: ");
    scanf("%d", &numBicicletasVendidas);

    // C�lculo do pre�o de venda de cada bicicleta (com 50% de acr�scimo)
    float precoVenda = precoCusto * 1.50;

    // C�lculo da comiss�o por vendedor (15% sobre o pre�o de custo de cada bicicleta)
    comissaoPorVendedor = precoCusto * 0.15;

    // C�lculo do lucro bruto da loja
    lucroBruto = (precoVenda - precoCusto) * numBicicletasVendidas;

    // C�lculo da comiss�o total dividida igualmente entre os vendedores
    float comissaoTotal = comissaoPorVendedor * numBicicletasVendidas;

    // C�lculo do sal�rio de cada empregado
    salarioEmpregado = salarioMinimo * 2 + comissaoTotal / numEmpregados;

    // C�lculo do lucro l�quido da loja (descontando os custos com sal�rios e comiss�es)
    lucroLiquido = lucroBruto - (numEmpregados * salarioMinimo * 2) - comissaoTotal;

    // Exibi��o dos resultados
    printf("\nSalario de cada empregado: R$ %.2f\n", salarioEmpregado);
    printf("Lucro liquido da loja: R$ %.2f\n", lucroLiquido);

    return 0;
}








