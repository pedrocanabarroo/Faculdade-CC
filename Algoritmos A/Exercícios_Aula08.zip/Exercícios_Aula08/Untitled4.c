#include <stdio.h>
#include <locale.h>


int main(){

int n, x;
setlocale(LC_ALL,"Portuguese");
for(x=1; x<=10; x++){
    printf("Digite um n�mero: ");
    scanf("%d", &n);

    if(n%2==0){
        printf("Par\n");
    } else{
        printf("Impar\n");
    }
}
return 0;

}
