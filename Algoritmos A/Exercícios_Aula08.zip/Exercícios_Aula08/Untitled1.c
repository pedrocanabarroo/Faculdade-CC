#include <stdio.h>
int main(){

int x;

for(x=10;x>=1;x--){
    printf("=========== %i\n", x);
}




}
