#include <stdio.h>
#include <locale.h>
int main(){

int n, a;
setlocale(LC_ALL,"Portuguese");
printf("Digite um n�mero maior que zero: ");
scanf("%d", &n);

if (n>0){
    for(a=1; a<=n; a++){
        printf("%d\n", a);
    }
}else{
    printf("O n�mero deve ser maior que zero!");
}
return 0;
}
